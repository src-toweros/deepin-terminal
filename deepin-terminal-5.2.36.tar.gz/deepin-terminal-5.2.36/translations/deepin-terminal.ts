<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>CustomCommandList</name>
    <message>
        <location filename="../src/customcommand/customcommandlist.cpp" line="163"/>
        <source>Are you sure you want to delete %1?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomCommandOptDlg</name>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="134"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="136"/>
        <source>Command:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="138"/>
        <source>Shortcuts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="144"/>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="145"/>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="166"/>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="173"/>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="180"/>
        <source>Add Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="186"/>
        <source>Edit Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="195"/>
        <source>Delete Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="220"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="222"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="224"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="305"/>
        <source>Please enter a name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="317"/>
        <source>Please enter a command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="366"/>
        <source>The name already exists,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="367"/>
        <source>please input another one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="626"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomCommandPanel</name>
    <message>
        <location filename="../src/customcommand/customcommandpanel.cpp" line="123"/>
        <source>Add Command</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomCommandPlugin</name>
    <message>
        <location filename="../src/customcommand/customcommandplugin.cpp" line="43"/>
        <source>Custom commands</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomCommandSearchRstPanel</name>
    <message>
        <location filename="../src/customcommand/customcommandsearchrstpanel.cpp" line="22"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DSettingsDialog</name>
    <message>
        <location filename="../src/common/utils.cpp" line="418"/>
        <source>This shortcut conflicts with %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/main/mainwindow.cpp" line="182"/>
        <location filename="../src/main/mainwindow.cpp" line="201"/>
        <source>New window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main/mainwindow.cpp" line="223"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main/mainwindow.cpp" line="536"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main/mainwindow.cpp" line="538"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main/mainwindow.cpp" line="1363"/>
        <source>Select workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main/mainwindow.cpp" line="1473"/>
        <source>Type path to download file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/views/warnningdlg.cpp" line="103"/>
        <location filename="../src/common/utils.cpp" line="386"/>
        <location filename="../src/common/utils.cpp" line="405"/>
        <location filename="../src/common/utils.cpp" line="502"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="7"/>
        <source>Copy on select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="10"/>
        <source>Cursor blink</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="12"/>
        <source>Cursor style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="14"/>
        <source>Scroll on keystroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="16"/>
        <source>Scroll on output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="18"/>
        <source>Hide Quake window after losing focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="20"/>
        <location filename="../src/main/service.cpp" line="140"/>
        <source>Blur background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="22"/>
        <source>Use on starting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="24"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="26"/>
        <source>Font size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="28"/>
        <location filename="../src/main/service.cpp" line="167"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="30"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="32"/>
        <source>Cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="34"/>
        <source>Scroll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="36"/>
        <source>Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="38"/>
        <source>Basic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="40"/>
        <source>Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="42"/>
        <source>Shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="44"/>
        <location filename="../src/main/mainwindow.cpp" line="1340"/>
        <source>Others</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="46"/>
        <location filename="../src/main/mainwindow.cpp" line="1338"/>
        <location filename="../src/main/main.cpp" line="36"/>
        <source>Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="48"/>
        <location filename="../src/main/mainwindow.cpp" line="1336"/>
        <source>Workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="50"/>
        <location filename="../src/main/mainwindow.cpp" line="1405"/>
        <source>Custom commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="52"/>
        <location filename="../src/main/mainwindow.cpp" line="1405"/>
        <source>Display shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="54"/>
        <location filename="../src/main/mainwindow.cpp" line="1405"/>
        <source>Remote management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="56"/>
        <location filename="../src/main/mainwindow.cpp" line="1405"/>
        <source>Rename title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="58"/>
        <location filename="../src/main/mainwindow.cpp" line="1405"/>
        <source>Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="60"/>
        <location filename="../src/main/mainwindow.cpp" line="1373"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="62"/>
        <location filename="../src/main/mainwindow.cpp" line="1373"/>
        <source>Default size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="64"/>
        <location filename="../src/main/mainwindow.cpp" line="1373"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="66"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="68"/>
        <location filename="../src/main/mainwindow.cpp" line="1373"/>
        <source>Select all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="70"/>
        <source>Jump to next command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="72"/>
        <source>Jump to previous command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="74"/>
        <location filename="../src/main/mainwindow.cpp" line="1373"/>
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="76"/>
        <location filename="../src/main/mainwindow.cpp" line="1373"/>
        <source>Zoom out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="78"/>
        <location filename="../src/main/mainwindow.cpp" line="1390"/>
        <source>Close other windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="80"/>
        <location filename="../src/main/mainwindow.cpp" line="1388"/>
        <source>Close other workspaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="82"/>
        <location filename="../src/main/mainwindow.cpp" line="1390"/>
        <source>Close window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="84"/>
        <location filename="../src/main/mainwindow.cpp" line="1388"/>
        <source>Close workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="86"/>
        <location filename="../src/main/mainwindow.cpp" line="1389"/>
        <source>Horizontal split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="88"/>
        <location filename="../src/main/mainwindow.cpp" line="1388"/>
        <source>New workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="90"/>
        <location filename="../src/main/mainwindow.cpp" line="1388"/>
        <source>Next workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="92"/>
        <location filename="../src/main/mainwindow.cpp" line="1388"/>
        <source>Previous workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="94"/>
        <location filename="../src/main/mainwindow.cpp" line="1390"/>
        <source>Select left window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="96"/>
        <location filename="../src/main/mainwindow.cpp" line="1389"/>
        <source>Select lower window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="98"/>
        <location filename="../src/main/mainwindow.cpp" line="1390"/>
        <source>Select right window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="100"/>
        <location filename="../src/main/mainwindow.cpp" line="1389"/>
        <source>Select upper window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="102"/>
        <location filename="../src/main/mainwindow.cpp" line="1389"/>
        <source>Vertical split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings_translation.cpp" line="104"/>
        <location filename="../src/main/mainwindow.cpp" line="1373"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfiglist.cpp" line="210"/>
        <location filename="../src/customcommand/customcommandlist.cpp" line="164"/>
        <location filename="../src/common/utils.cpp" line="307"/>
        <location filename="../src/common/utils.cpp" line="386"/>
        <location filename="../src/common/utils.cpp" line="404"/>
        <location filename="../src/common/utils.cpp" line="426"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfiglist.cpp" line="211"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main/service.cpp" line="315"/>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="629"/>
        <location filename="../src/common/utils.cpp" line="437"/>
        <location filename="../src/common/utils.cpp" line="444"/>
        <source>please set another one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main/main.cpp" line="42"/>
        <source>Terminal is an advanced terminal emulator with workspace, multiple windows, remote management, quake mode and other features.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="283"/>
        <source>Select file to upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="288"/>
        <source>Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="305"/>
        <location filename="../src/common/utils.cpp" line="372"/>
        <source>Programs are still running in terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="306"/>
        <source>Are you sure you want to exit?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="307"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="320"/>
        <location filename="../src/common/utils.cpp" line="358"/>
        <source>Close this terminal?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="321"/>
        <location filename="../src/common/utils.cpp" line="359"/>
        <source>There is still a process running in this terminal. Closing the terminal will kill it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="325"/>
        <location filename="../src/common/utils.cpp" line="363"/>
        <source>There are still %1 processes running in this terminal. Closing the terminal will kill all of them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="330"/>
        <location filename="../src/common/utils.cpp" line="354"/>
        <source>Close this window?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="331"/>
        <location filename="../src/common/utils.cpp" line="355"/>
        <source>There are still processes running in this window. Closing the window will kill all of them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="262"/>
        <source>Select a directory to save the file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="372"/>
        <source>Are you sure you want to uninstall it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="384"/>
        <location filename="../src/common/utils.cpp" line="394"/>
        <location filename="../src/common/utils.cpp" line="398"/>
        <source>Are you sure you want to uninstall this application?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="385"/>
        <location filename="../src/common/utils.cpp" line="395"/>
        <location filename="../src/common/utils.cpp" line="399"/>
        <source>You will not be able to use Terminal any longer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="425"/>
        <source>Click on Add to make this shortcut effective immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="426"/>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="559"/>
        <source>Execute a command in the terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="562"/>
        <source>Run script string in the terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="553"/>
        <source>Set the work directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="556"/>
        <source>Set the window mode on starting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="566"/>
        <source>Run in quake mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="569"/>
        <source>Keep terminal open when command finishes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="461"/>
        <location filename="../src/customcommand/customcommandoptdlg.cpp" line="311"/>
        <source>The name should be no more than 32 characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="536"/>
        <location filename="../src/common/utils.cpp" line="268"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="532"/>
        <source>Select the private key file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/customcommand/customcommandlist.cpp" line="165"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main/mainwindow.cpp" line="1389"/>
        <source>Select workspace</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RemoteManagementPanel</name>
    <message>
        <location filename="../src/remotemanage/remotemanagementpanel.cpp" line="78"/>
        <source>Add Server</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RemoteManagementPlugn</name>
    <message>
        <location filename="../src/remotemanage/remotemanagementplugn.cpp" line="41"/>
        <source>Remote management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/remotemanagementplugn.cpp" line="142"/>
        <source>Make sure that rz and sz commands have been installed in the server before right clicking to upload and download files.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RemoteManagementSearchPanel</name>
    <message>
        <location filename="../src/remotemanage/remotemanagementsearchpanel.cpp" line="136"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ServerConfigList</name>
    <message>
        <location filename="../src/remotemanage/serverconfiglist.cpp" line="147"/>
        <source>%1 server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfiglist.cpp" line="194"/>
        <source>Delete Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfiglist.cpp" line="194"/>
        <source>Are you sure you want to delete %1?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ServerConfigOptDlg</name>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="44"/>
        <source>Advanced options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="64"/>
        <source>Add Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="103"/>
        <source>Server name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="106"/>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="112"/>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="141"/>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="110"/>
        <source>Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="118"/>
        <source>Port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="139"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="145"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="152"/>
        <source>Certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="178"/>
        <source>Group:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="184"/>
        <source>Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="190"/>
        <source>Command:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="196"/>
        <source>Encoding:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="202"/>
        <source>Backspace key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="208"/>
        <source>Delete key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="222"/>
        <source>Delete server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="242"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="243"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="247"/>
        <source>Edit Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="347"/>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="358"/>
        <source>tty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="455"/>
        <source>Please enter a server name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="468"/>
        <source>Please enter an IP address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="473"/>
        <source>Please enter a port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="479"/>
        <source>Please enter a username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="248"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="343"/>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="355"/>
        <source>ascii-del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="344"/>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="356"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="345"/>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="357"/>
        <source>control-h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="346"/>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="354"/>
        <source>escape-sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="493"/>
        <source>The server name already exists,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/remotemanage/serverconfigoptdlg.cpp" line="494"/>
        <source>please input another one. </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Service</name>
    <message>
        <location filename="../src/main/service.cpp" line="313"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../src/settings/settings.cpp" line="75"/>
        <source>Split screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings.cpp" line="75"/>
        <source>Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings.cpp" line="75"/>
        <source>Normal window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/settings.cpp" line="75"/>
        <source>Maximum</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShortcutManager</name>
    <message>
        <location filename="../src/settings/shortcutmanager.cpp" line="265"/>
        <location filename="../src/settings/shortcutmanager.cpp" line="274"/>
        <source>The shortcut %1 is invalid, </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/settings/shortcutmanager.cpp" line="281"/>
        <location filename="../src/settings/shortcutmanager.cpp" line="288"/>
        <location filename="../src/settings/shortcutmanager.cpp" line="294"/>
        <source>The shortcut %1 was already in use, </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabBar</name>
    <message>
        <location filename="../src/views/tabbar.cpp" line="379"/>
        <source>Close workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/tabbar.cpp" line="380"/>
        <source>Close other workspaces</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TermInputDialog</name>
    <message>
        <location filename="../src/views/terminputdialog.cpp" line="154"/>
        <source>Rename title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/terminputdialog.cpp" line="180"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/terminputdialog.cpp" line="181"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TermWidget</name>
    <message>
        <location filename="../src/views/termwidget.cpp" line="365"/>
        <source>Rename title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="262"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="265"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="271"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="282"/>
        <source>Open in file manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="293"/>
        <location filename="../src/views/termwidget.cpp" line="414"/>
        <source>Horizontal split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="299"/>
        <location filename="../src/views/termwidget.cpp" line="414"/>
        <source>Vertical split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="306"/>
        <source>Close window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="311"/>
        <source>Close other windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="318"/>
        <location filename="../src/views/termwidget.cpp" line="414"/>
        <source>New workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="327"/>
        <source>Exit fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="331"/>
        <source>Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="337"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="343"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="382"/>
        <source>Encoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="386"/>
        <source>Custom commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="390"/>
        <source>Remote management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="396"/>
        <source>Upload file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="399"/>
        <source>Download file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/views/termwidget.cpp" line="406"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Utils</name>
    <message>
        <location filename="../src/common/utils.cpp" line="336"/>
        <location filename="../src/common/utils.cpp" line="374"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="338"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/common/utils.cpp" line="375"/>
        <location filename="../src/common/utils.cpp" line="446"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
